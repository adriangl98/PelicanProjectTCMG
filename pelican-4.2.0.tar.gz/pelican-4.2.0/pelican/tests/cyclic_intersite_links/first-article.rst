First article
#############

:date: 2018-11-10
:summary: Here's the `second <{filename}/second-article.rst>`_,
    `third <{filename}/third-article.rst>`_ and a
    `nonexistent article <{filename}/nonexistent.rst>`_.
